#!/usr/bin/env python3
"""Chunk page records, embed them, and persist a cosine-similarity index."""
import argparse
import json
import re
from pathlib import Path
import numpy as np
from sentence_transformers import SentenceTransformer

def chunk_text(text, max_chars=1100, overlap=180):
    """Character-based chunking, preserving line boundaries where practical."""
    text = re.sub(r"[ \t]+", " ", text or "").strip()
    if not text:
        return []
    chunks = []
    start = 0
    while start < len(text):
        end = min(start + max_chars, len(text))
        if end < len(text):
            boundary = text.rfind("\n", start, end)
            if boundary > start + int(max_chars * 0.55):
                end = boundary
        part = text[start:end].strip()
        if part:
            chunks.append(part)
        if end >= len(text):
            break
        start = max(end - overlap, start + 1)
    return chunks

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, help="Page JSONL from extract_pdf.py")
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--model", default="sentence-transformers/all-MiniLM-L6-v2")
    parser.add_argument("--max-chars", type=int, default=1100)
    parser.add_argument("--overlap", type=int, default=180)
    parser.add_argument("--batch-size", type=int, default=32)
    args = parser.parse_args()

    in_path, out_dir = Path(args.input), Path(args.out_dir)
    if not in_path.exists():
        raise SystemExit(f"Input JSONL not found: {in_path}")
    out_dir.mkdir(parents=True, exist_ok=True)

    chunks = []
    with in_path.open(encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            page = json.loads(line)
            for i, piece in enumerate(chunk_text(page.get("text", ""), args.max_chars, args.overlap)):
                chunks.append({
                    "chunk_id": len(chunks),
                    "page": page.get("page"),
                    "section": page.get("section"),
                    "section_title": page.get("section_title"),
                    "chunk_on_page": i,
                    "text": piece,
                })

    if not chunks:
        raise SystemExit("No text chunks found. Check the PDF extraction output.")

    print(f"Embedding {len(chunks)} chunks using {args.model} ...")
    model = SentenceTransformer(args.model)
    texts = [c["text"] for c in chunks]
    embeddings = model.encode(
        texts, batch_size=args.batch_size, show_progress_bar=True,
        convert_to_numpy=True, normalize_embeddings=True
    ).astype(np.float32)

    with (out_dir / "chunks.jsonl").open("w", encoding="utf-8") as f:
        for chunk in chunks:
            f.write(json.dumps(chunk, ensure_ascii=False) + "\n")
    np.save(out_dir / "embeddings.npy", embeddings)
    metadata = {
        "embedding_model": args.model,
        "chunk_count": len(chunks),
        "embedding_dimension": int(embeddings.shape[1]),
        "max_chars": args.max_chars,
        "overlap": args.overlap,
    }
    (out_dir / "index_metadata.json").write_text(
        json.dumps(metadata, indent=2), encoding="utf-8"
    )
    print(f"Saved index to {out_dir} ({len(chunks)} chunks).")

if __name__ == "__main__":
    main()
