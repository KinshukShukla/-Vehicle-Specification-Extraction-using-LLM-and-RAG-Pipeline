#!/usr/bin/env python3
"""Retrieve evidence and extract structured vehicle specifications."""
import argparse
import csv
import json
import os
import re
from pathlib import Path
import numpy as np
from sentence_transformers import SentenceTransformer

SYSTEM_PROMPT = """You extract vehicle specifications from service-manual evidence.
Use ONLY the supplied evidence. Do not use outside knowledge or guess.
Return valid JSON only, with this exact top-level shape:
{"answer":[{"specification_type":"torque|fluid_capacity|part_number|other",
"component":"specific component name","value":number_or_string,"unit":"unit or null",
"qualifier":"conditions/variant if stated, otherwise null",
"source":{"page":integer,"section":"section code or null","section_title":"title or null"}}]}
Rules:
- Include only values directly supported by the evidence.
- Keep units and qualifiers exactly as stated when possible.
- Distinguish similar fasteners/components; never transfer a value between them.
- If evidence does not answer the question, return {"answer":[]}.
- Do not include explanations outside the JSON object.
"""

def load_jsonl(path):
    with Path(path).open(encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]

def regex_fallback(question, retrieved):
    """Very simple fallback for smoke testing; not a reliable LLM replacement."""
    answers = []
    q = question.lower()
    for c in retrieved:
        text = c["text"]
        patterns = [
            (r"(?P<component>[^.\n]{0,100}?(?:bolt|bolts|nut|nuts|screw|fastener)[^.\n]{0,80}?)\s+(?:[:\-]\s*)?(?P<value>\d+(?:\.\d+)?)\s*(?P<unit>Nm|N·m|lb-ft|ft-lb|lb\.?\s*ft)\b", "torque"),
            (r"(?P<component>[^.\n]{0,100}?(?:fluid|capacity)[^.\n]{0,80}?)\s+(?:[:\-]\s*)?(?P<value>\d+(?:,\d{3})*(?:\.\d+)?)\s*(?P<unit>ml|mL|L|liters?|pt|qt|gal)\b", "fluid_capacity"),
            (r"(?P<component>[^.\n]{0,100}?(?:part number|part no\.?|P/N)[^.\n]{0,60}?)\s*[:#]?\s*(?P<value>[A-Z0-9][A-Z0-9\-]{3,})", "part_number"),
        ]
        for pattern, typ in patterns:
            for m in re.finditer(pattern, text, re.IGNORECASE):
                comp = re.sub(r"\s+", " ", m.group("component")).strip(" :;,-")
                # Keep fallback conservative: only return candidates with query overlap.
                terms = [t for t in re.findall(r"[a-z0-9]+", q) if len(t) > 3]
                if terms and not any(t in (comp + " " + text).lower() for t in terms):
                    continue
                val = m.group("value").replace(",", "")
                try:
                    val = float(val) if "." in val else int(val)
                except ValueError:
                    pass
                answers.append({
                    "specification_type": typ,
                    "component": comp or "Not clearly identified",
                    "value": val,
                    "unit": m.groupdict().get("unit"),
                    "qualifier": None,
                    "source": {
                        "page": c.get("page"),
                        "section": c.get("section"),
                        "section_title": c.get("section_title"),
                    },
                })
                if len(answers) >= 8:
                    return answers
    return answers

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--index-dir", required=True)
    parser.add_argument("--question", required=True)
    parser.add_argument("--top-k", type=int, default=6)
    parser.add_argument("--csv", default=None, help="Optional CSV output path")
    parser.add_argument("--model", default=None, help="Override embedding model")
    args = parser.parse_args()

    index_dir = Path(args.index_dir)
    metadata = json.loads((index_dir / "index_metadata.json").read_text(encoding="utf-8"))
    model_name = args.model or metadata["embedding_model"]
    chunks = load_jsonl(index_dir / "chunks.jsonl")
    embeddings = np.load(index_dir / "embeddings.npy")

    embedder = SentenceTransformer(model_name)
    qvec = embedder.encode([args.question], convert_to_numpy=True, normalize_embeddings=True)[0]
    #scores = embeddings @ qvec
    #top_ids = np.argsort(scores)[::-1][:max(1, args.top_k)]
    # Semantic similarity scores
    semantic_scores = embeddings @ qvec

    # Keyword-based scoring to improve exact specification retrieval
    import re

    stop_words = {
        "what", "is", "the", "for", "a", "an", "of",
        "to", "and", "in", "on", "with", "are", "does"
    }

    query_terms = set(
        re.findall(r"[a-z0-9]+", args.question.lower())
    ) - stop_words

    hybrid_scores = []

    for i, chunk in enumerate(chunks):
        # Include section metadata in the searchable text
        searchable_text = " ".join([
            chunk.get("section", "") or "",
            chunk.get("section_title", "") or "",
            chunk.get("text", "") or ""
        ]).lower()

        chunk_terms = set(re.findall(r"[a-z0-9]+", searchable_text))

        # Fraction of query keywords found in this chunk
        if query_terms:
            keyword_score = len(query_terms & chunk_terms) / len(query_terms)
        else:
            keyword_score = 0.0

        # Reward chunks that contain the main component phrase
        component_phrases = [
            "caliper guide pin bolts",
            "caliper anchor plate bolts",
            "brake fluid capacity",
        ]

        phrase_bonus = 0.0
        normalized_text = re.sub(r"\s+", " ", searchable_text)

        for phrase in component_phrases:
            if phrase in normalized_text and phrase in args.question.lower():
                phrase_bonus = 0.15
                break

        # Combine semantic and keyword relevance
        final_score = (
            0.60 * float(semantic_scores[i])
            + 0.40 * keyword_score
            + phrase_bonus
        )

        hybrid_scores.append(final_score)

    hybrid_scores = np.array(hybrid_scores)

    # Retrieve the chunks with the highest combined scores
    top_ids = np.argsort(hybrid_scores)[::-1][:max(1, args.top_k)]
    scores = hybrid_scores
    retrieved = []
    for idx in top_ids:
        c = dict(chunks[int(idx)])
        c["similarity"] = round(float(scores[idx]), 4)
        retrieved.append(c)

    evidence_text = "\n\n".join(
        f"[Evidence {i+1} | PDF page {c.get('page')} | section {c.get('section')} | {c.get('section_title')}]\n{c['text']}"
        for i, c in enumerate(retrieved)
    )

    api_key = os.getenv("OPENAI_API_KEY")
    if api_key:
        try:
            from openai import OpenAI
            client = OpenAI(api_key=api_key)
            model = os.getenv("OPENAI_MODEL", "gpt-4.1-mini")
            response = client.chat.completions.create(
                model=model,
                temperature=0,
                response_format={"type": "json_object"},
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": f"Question: {args.question}\n\nEvidence:\n{evidence_text}"},
                ],
            )
            parsed = json.loads(response.choices[0].message.content)
            answer = parsed.get("answer", [])
            method = f"openai:{model}"
        except Exception as exc:
            print(f"WARNING: LLM call failed ({exc}); using regex fallback.")
            answer = regex_fallback(args.question, retrieved)
            method = "regex_fallback_after_llm_error"
    else:
        print("OPENAI_API_KEY is not set; using the limited regex fallback.")
        answer = regex_fallback(args.question, retrieved)
        method = "regex_fallback"

    result = {
        "question": args.question,
        "answer": answer,
        "evidence": [
            {
                "page": c.get("page"),
                "section": c.get("section"),
                "section_title": c.get("section_title"),
                "similarity": c.get("similarity"),
                "text": c.get("text"),
            } for c in retrieved
        ],
        "method": method,
    }
    print(json.dumps(result, indent=2, ensure_ascii=False))

    if args.csv:
        csv_path = Path(args.csv)
        csv_path.parent.mkdir(parents=True, exist_ok=True)
        fields = ["specification_type", "component", "value", "unit", "qualifier",
                  "page", "section", "section_title"]
        with csv_path.open("w", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            for item in answer:
                source = item.get("source") or {}
                writer.writerow({
                    "specification_type": item.get("specification_type"),
                    "component": item.get("component"),
                    "value": item.get("value"),
                    "unit": item.get("unit"),
                    "qualifier": item.get("qualifier"),
                    "page": source.get("page"),
                    "section": source.get("section"),
                    "section_title": source.get("section_title"),
                })
        print(f"CSV saved to {csv_path}")

if __name__ == "__main__":
    main()
