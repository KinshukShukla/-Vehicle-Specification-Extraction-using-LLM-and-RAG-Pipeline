#!/usr/bin/env python3
"""Extract searchable text from a PDF into JSONL, one record per page."""
import argparse
import json
import re
from pathlib import Path
#import fitz  # PyMuPDF
import pymupdf as fitz

SECTION_RE = re.compile(
    r"\bSECTION\s+([0-9]{3}-[0-9]{2})\s*(?:[-–—:]\s*)?([^\r\n]*)",
    re.IGNORECASE,
)

def detect_section(text: str):
    """Return the first section code/title visible on this page, if any."""
    match = SECTION_RE.search(text or "")
    if not match:
        return None, None
    code = match.group(1).strip()
    title = re.sub(r"\s+", " ", match.group(2)).strip(" -:\t")
    return code, (title or None)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--pdf", required=True, help="Input searchable PDF")
    parser.add_argument("--out", required=True, help="Output JSONL path")
    args = parser.parse_args()

    pdf_path = Path(args.pdf)
    out_path = Path(args.out)
    if not pdf_path.exists():
        raise SystemExit(f"PDF not found: {pdf_path}")

    out_path.parent.mkdir(parents=True, exist_ok=True)
    current_section = None
    current_title = None
    empty_pages = 0
    page_count = 0

    with fitz.open(pdf_path) as doc, out_path.open("w", encoding="utf-8") as fout:
        page_count = len(doc)
        for page_no, page in enumerate(doc, start=1):
            text = page.get_text("text", sort=True).strip()
            found_section, found_title = detect_section(text)
            if found_section:
                current_section = found_section
                current_title = found_title
            if len(text) < 20:
                empty_pages += 1
            record = {
                "page": page_no,
                "section": current_section,
                "section_title": current_title,
                "text": text,
            }
            fout.write(json.dumps(record, ensure_ascii=False) + "\n")

    print(f"Extracted {page_count} pages -> {out_path}")
    print(f"Pages with fewer than 20 text characters: {empty_pages}")
    if empty_pages:
        print("Some pages may be scanned/image-only; OCR is not included in this text-only baseline.")

if __name__ == "__main__":
    main()
